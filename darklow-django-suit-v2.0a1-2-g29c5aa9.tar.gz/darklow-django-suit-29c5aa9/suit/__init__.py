VERSION = '2.0a2'
default_app_config = 'suit.apps.DjangoSuitConfig'
